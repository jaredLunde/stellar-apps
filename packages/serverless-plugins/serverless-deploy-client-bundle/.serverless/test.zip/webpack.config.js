const zlib = require('zlib')
const path = require('path')
const CompressionPlugin = require('compression-webpack-plugin')


module.exports = {
  name: 'client',
  mode: 'production',
  entry: [path.join(__dirname, 'faux-index.js')],
  output: {
    path: path.join(__dirname, 'faux-dist'),
    publicPath: '/public/',
    filename: `js/app.[hash].js`,
    chunkFilename: `js/app.[chunkhash].js`,
  },
  module: {
    rules: [
      {
        test: /\.m?js$/,
        include: /node_modules/,
        type: 'javascript/auto',
      }
    ]
  },
  plugins: [
    new CompressionPlugin({
      test: /\.js(\?.*)?$/i,
      cache: true,
      algorithm: 'gzip',
      threshold: 0,
      filename: '[path]',
      compressionOptions: {
        level: zlib.Z_BEST_COMPRESSION,
        memLevel: zlib.Z_BEST_COMPRESSION,
      }
    })
  ],
}